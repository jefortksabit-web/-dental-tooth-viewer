FINAL ONE-TOOTH INTERACTIVE VERSION

Open index.html in a web browser through a web server / hosted site.
The self-contained Dental_Medicine_HEIs_ONE_TOOTH_INTERACTIVE_FINAL.html
contains the GLB asset embedded in the file itself.

Interaction:
- Swipe/drag left or right: rotate the SAME 3D tooth
- Pinch/wheel: zoom
- Buttons: snap to Front / Right / Back / Left
- Vertical orbit is locked so the data sides stay readable

Files:
- tooth_dashboard.glb : genuine 3D browser model
- tooth_dashboard.usdz: Apple Quick Look version
- index.html: browser viewer
